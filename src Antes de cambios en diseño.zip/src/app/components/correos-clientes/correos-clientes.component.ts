import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UsuariosService } from 'src/app/services/usuarios/usuarios.service';
import { CorreosService } from 'src/app/services/correos/correos.service';


@Component({
  selector: 'app-correos-clientes',
  templateUrl: './correos-clientes.component.html',
  styleUrls: ['./correos-clientes.component.css']
})
export class CorreosClientesComponent implements OnInit {
  
  formFiltros: FormGroup;
  errorMessage:string; 
  Usuario : any;
  
  empresaSeleccionada: number=0;
  Empresas: any;

  Correos: any[] = [];

  constructor(private fb: FormBuilder, private UsuariosService:UsuariosService, private CorreosService:CorreosService) { 
    this.empresaSeleccionada = 0;
    this.errorMessage ="";
    this.Empresas = [{ID:0, RFCEmisor:"Selecciona una Empresa"}];

    this.formFiltros = this.fb.group({
      empresaSeleccionada: [0],
      RFCCliente: [''],
      noClienteSAP: ['']
    });

    this.Usuario = JSON.parse(sessionStorage.getItem("Usuario")!);
    
  }

  ngOnInit(): void {
    this.getEmpresas();
  }

  

  getEmpresas(){

    /**
     * Consumimos el service para obtener los permisos
     */
    this.UsuariosService.Get(this.Usuario['Username']).subscribe(
      data => {
        this.Empresas = data["Permisos_Emisor"];
        console.log(this.Empresas);
        this.formFiltros = this.fb.group({
          empresaSeleccionada: [this.Empresas[0]["RFCEmisor"]],
          RFCCliente: [''],
          noClienteSAP: ['']
        });
      },
      error => {
        switch(error.error) { 
          case "TokenInvalido": { 
            sessionStorage.removeItem('Usuario');    
            sessionStorage.clear();  
            this.Usuario = null;
            alert("La sesion expiró");
            window.location.href ='/login';
            // this.router.navigate(['/login']);  
             break; 
          } 
          default: { 
             //statements; 
             break; 
          } 
        } 
      }
    );
  }

  getCorreos(){
    this.Correos = [];
    debugger
    var Emisor = this.getCiaSAP(this.formFiltros.get('empresaSeleccionada')?.value.trim());
    var RFCCliente = this.formFiltros.get('RFCCliente')?.value;
    var Cliente = this.formFiltros.get('noClienteSAP')?.value;

    this.CorreosService.GetByClienteAndEmisor(Cliente,RFCCliente,Emisor).subscribe(
      data=>{
        console.log(data);
        if(data.length > 0)    
        {       
          this.Correos = data
        }    
        else{    
          this.errorMessage = data.ID;    
        }
      },
      error => {
        switch(error.error) { 
          case "TokenInvalido": { 
            sessionStorage.removeItem('Usuario');    
            sessionStorage.clear();  
            this.Usuario = null;
            alert("La sesion expiró");
            window.location.href ='/login';
            // this.router.navigate(['/login']);  
             break; 
          } 
          default: { 
             //statements; 
             break; 
          } 
        } 
      }
    );

  }

  getCiaSAP(Emisor: string){
    var ciaSAP;
    switch(Emisor) { 
      case "FGM790801SD7": { 
        ciaSAP = "5550";
         break; 
      } case "IBI790703DX4": { 
        ciaSAP = "5512";
         break; 
      } case "CMO881228RR9  ": { 
        ciaSAP = "5510";
         break; 
      } 
      default: { 
         ciaSAP = "0";
         break; 
      } 
    }
  return ciaSAP;
  }

}
