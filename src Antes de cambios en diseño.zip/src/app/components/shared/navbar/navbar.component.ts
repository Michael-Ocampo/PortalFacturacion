import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {
  Usuario: any;
  constructor() { 
    this.Usuario = JSON.parse(sessionStorage.getItem("Usuario")!);
  }

  ngOnInit(): void {
   
  }

 

  logOut(){
    this.Usuario = null;  
    sessionStorage.removeItem('Usuario');    
    sessionStorage.clear();  
    window.location.href ='/login';
    // this.router.navigate(['/login']);   
    
  }

}
