import { FileToUpload } from './file-to-upload';

describe('FileToUpload', () => {
  it('should create an instance', () => {
    expect(new FileToUpload()).toBeTruthy();
  });
});
