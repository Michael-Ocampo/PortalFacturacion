import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';  
import {HttpHeaders} from '@angular/common/http';  
import { from, Observable } from 'rxjs';  


@Injectable({
  providedIn: 'root'
})
export class LoginService {
  Url :string;  
  //token : string;  
  header : any;
  constructor(private http : HttpClient) {   

     this.Url = 'http://localhost:52624/';  
    //this.Url = 'https://SRV20-WEB.cmoderna.com/API_FacturacionQA/';  
    //this.Url = 'https://SRV20-WEB.cmoderna.com/API_Facturacion/';  

    this.Url = this.Url + 'api/login/'
    
    const headerSettings: {[name: string]: string | string[]; } = {};  
    this.header = new HttpHeaders(headerSettings);  
  }  

  Login(LoginRequest : any){  
    
     var a =this.Url+'authenticate';  
    return this.http.post<any>(this.Url+'authenticate',LoginRequest,{ headers: this.header});  
  }  


}
